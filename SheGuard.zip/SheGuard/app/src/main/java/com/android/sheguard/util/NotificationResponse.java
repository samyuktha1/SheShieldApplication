package com.android.sheguard.util;

@SuppressWarnings("unused")
public class NotificationResponse {
    public int success;
}
